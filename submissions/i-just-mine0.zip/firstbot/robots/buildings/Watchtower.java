package firstbot.robots.buildings;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Watchtower extends Building {
  public Watchtower(RobotController rc) {
    super(rc);
  }

  @Override
  protected void runTurn() throws GameActionException {

  }
}
