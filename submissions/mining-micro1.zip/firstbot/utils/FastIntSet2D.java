package firstbot.utils;

public class FastIntSet2D {
}
