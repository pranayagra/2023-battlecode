package firstbot.robots.droids;

import battlecode.common.RobotController;
import firstbot.robots.Robot;

public abstract class Droid extends Robot {
  public Droid(RobotController rc) {
    super(rc);
  }
}
