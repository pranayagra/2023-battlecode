package firstbot.robots.droids;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Builder extends Droid {
  public Builder(RobotController rc) {
    super(rc);
  }

  @Override
  protected void runTurn() throws GameActionException {
    moveRandomly();
    rc.disintegrate();
  }
}
