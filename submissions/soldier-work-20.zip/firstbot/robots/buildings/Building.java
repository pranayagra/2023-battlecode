package firstbot.robots.buildings;

import battlecode.common.RobotController;
import firstbot.robots.Robot;

public abstract class Building extends Robot {
  public Building(RobotController rc) {
    super(rc);
  }
}
